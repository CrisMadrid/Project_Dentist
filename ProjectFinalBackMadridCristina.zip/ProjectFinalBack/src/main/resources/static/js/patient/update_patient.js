window.addEventListener('load', function () {



    const formulario = document.querySelector('#update_patient_form');

    formulario.addEventListener('submit', function (event) {
        let pacienteId = document.querySelector('#patient_id').value;


        const formData = {
                       id: document.querySelector('#patient_id').value,
                       name: document.querySelector('#name').value,
                       lastName: document.querySelector('#lastName').value,
                       identityCard: document.querySelector('#identityCard').value,
                       dateOfAdmission: document.querySelector('#dateOfAdmission').value,
                       email: document.querySelector('#email').value,
                       address:{
                           id: document.querySelector('#address_id').value,
                           street: document.querySelector('#street').value,
                           number: document.querySelector('#number').value,
                           locality: document.querySelector('#locality').value,
                           province: document.querySelector('#province').value,
                       }

        };


        const url = '/patients';
        const settings = {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        }
          fetch(url,settings)
          .then(response => response.json())

    })
 })


    function findBy(id) {
          const url = '/patients'+"/"+id;
          const settings = {
              method: 'GET'
          }
          fetch(url,settings)
          .then(response => response.json())
          .then(data => {
              let paciente = data;

              document.querySelector('#patient_id').value = patient.id;
              document.querySelector('#name').value = patient.name;
              document.querySelector('#lastName').value = patient.lastName;
              document.querySelector('#identityCard').value = patient.identityCard;
              document.querySelector('#dateOfAdmission').value = patient.dateOfAdmission;
              document.querySelector('#email').value = patient.email;
              document.querySelector('#address_id').value = patient.address.id;
              document.querySelector('#street').value = patient.address.street;
              document.querySelector('#number').value = patient.address.number;
              document.querySelector('#locality').value = patient.address.locality;
              document.querySelector('#province').value = patient.address.province;
              document.querySelector('#div_patient_updating').style.display = "block";
          }).catch(error => {
              alert("Error: " + error);
          })
      }