window.addEventListener('load', function () {


    const formulario = document.querySelector('#add_new_patient');


    formulario.addEventListener('submit', function (event) {

        const formData = {
            name: document.querySelector('#name').value,
            lastName: document.querySelector('#lastName').value,
            identityCard: document.querySelector('#identityCard').value,
            dateOfAdmission: document.querySelector('#dateOfAdmission').value,
            email: document.querySelector('#email').value,
            address:{
                street: document.querySelector('#street').value,
                number: document.querySelector('#number').value,
                locality: document.querySelector('#locality').value,
                province: document.querySelector('#province').value,
            }

        };

        const url = '/patients';
        const settings = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        }

        fetch(url, settings)
            .then(response => response.json())
            .then(data => {

                 let successAlert = '<div class="alert alert-success alert-dismissible">' +
                     '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                     '<strong></strong> added patient </div>'

                 document.querySelector('#response').innerHTML = successAlert;
                 document.querySelector('#response').style.display = "block";
                 resetUploadForm();

            })
            .catch(error => {
                    //Si hay algun error se muestra un mensaje diciendo que la pelicula
                    //no se pudo guardar y se intente nuevamente
                    let errorAlert = '<div class="alert alert-danger alert-dismissible">' +
                                     '<button type="button" class="close" data-dismiss="alert">&times;</button>' +
                                     '<strong> Error try again</strong> </div>'

                      document.querySelector('#response').innerHTML = errorAlert;
                      document.querySelector('#response').style.display = "block";
                     //se dejan todos los campos vacíos por si se quiere ingresar otra pelicula
                     resetUploadForm();})
    });


    function resetUploadForm(){
        document.querySelector('#name').value = "";
        document.querySelector('#lastName').value = "";
        document.querySelector('#identityCard').value = "";
        document.querySelector('#dateOfAdmission').value = "";
        document.querySelector('#email').value = "";
        document.querySelector('#street').value = "";
        document.querySelector('#number').value = "";
        document.querySelector('#locality').value = "";
        document.querySelector('#province').value = "";

    }

    (function(){
        let pathname = window.location.pathname;
        if(pathname === "/"){
            document.querySelector(".nav .nav-item a:first").addClass("active");
        } else if (pathname == "/get_patients.html") {
            document.querySelector(".nav .nav-item a:last").addClass("active");
        }
    })();
});