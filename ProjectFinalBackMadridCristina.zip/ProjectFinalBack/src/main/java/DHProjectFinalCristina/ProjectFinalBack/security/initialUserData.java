package DHProjectFinalCristina.ProjectFinalBack.security;

import DHProjectFinalCristina.ProjectFinalBack.entity.User;
import DHProjectFinalCristina.ProjectFinalBack.entity.UserRole;
import DHProjectFinalCristina.ProjectFinalBack.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class initialUserData implements ApplicationRunner {
    @Autowired
    UserRepository userRepository;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        BCryptPasswordEncoder encrypter = new BCryptPasswordEncoder();
        String passwWhitoutEncrypter = "user";
        String passWhitEncrypter = encrypter.encode(passwWhitoutEncrypter);
        User userToInTo= new User("User","userN","user@gmail.com",passWhitEncrypter, UserRole.ROLE_USER);
        userRepository.save(userToInTo);
        String passWhitEncrypter2 = encrypter.encode("admin");
        userToInTo = new User("Admin","AdminP","admin@gmail.com",passWhitEncrypter2,UserRole.ROLE_ADMIN);
        userRepository.save(userToInTo);

    }
}
