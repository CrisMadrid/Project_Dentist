package DHProjectFinalCristina.ProjectFinalBack.controller;

import DHProjectFinalCristina.ProjectFinalBack.entity.Dentist;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.service.DentistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dentists")
public class DentistController {
    private DentistService dentistService;

    @Autowired
    public DentistController(DentistService dentistService) {
        this.dentistService = dentistService;
    }

    @PostMapping
    public ResponseEntity<Dentist> registerDentist(@RequestBody Dentist dentist){
        return ResponseEntity.ok(dentistService.saveDentist(dentist));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Dentist> dentistSearch(@PathVariable Long id) throws ResourceNotFoundException {
        return ResponseEntity.ok(dentistService.searchDentist(id).get());
    }

    @PutMapping
    public ResponseEntity<String> dentistUpdate(@RequestBody Dentist dentist) throws ResourceNotFoundException{
        dentistService.updateDentist(dentist);
        return ResponseEntity.ok("The dentist with id: " + dentist.getId() +", was updated");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> dentistDelete(@PathVariable Long id) throws ResourceNotFoundException {
        dentistService.deleteDentist(id);
        return ResponseEntity.ok("Removed dentist with id: " + id);
    }

    @GetMapping
    public ResponseEntity<List<Dentist>> dentistsList() throws ResourceNotFoundException {
        return ResponseEntity.ok( dentistService.listdentists());
    }

}
