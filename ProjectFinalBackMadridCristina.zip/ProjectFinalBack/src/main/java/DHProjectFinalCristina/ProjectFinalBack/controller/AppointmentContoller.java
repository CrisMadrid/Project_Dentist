package DHProjectFinalCristina.ProjectFinalBack.controller;

import DHProjectFinalCristina.ProjectFinalBack.dto.AppointmentDTO;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.BadRequestException;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.service.AppointmentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/appointments")
public class AppointmentContoller {
    private AppointmentService appointmentService;
    @Autowired
    public AppointmentContoller(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }
    @PostMapping
    public ResponseEntity<AppointmentDTO> appointmentRegister(@RequestBody AppointmentDTO appointmentDTO) throws BadRequestException {
        return ResponseEntity.ok(appointmentService.saveAppointment(appointmentDTO));
    }
    @GetMapping("/{id}")
    public ResponseEntity<AppointmentDTO> appointmentSearch(@PathVariable Long id) throws BadRequestException {
        return ResponseEntity.ok(appointmentService.searchAppointment(id).get());
    }
    @PutMapping
    public ResponseEntity<String> appointmentUpdate(@RequestBody AppointmentDTO appointmentDTO) throws ResourceNotFoundException {
        appointmentService.updateAppointment(appointmentDTO);
        return ResponseEntity.ok("The appointment with id: " + appointmentDTO.getId() +", was updated");
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> appointmentDelete(@PathVariable Long id) throws ResourceNotFoundException {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.ok("Removed appointment with id: " + id);
    }
    @GetMapping
    public ResponseEntity<List<AppointmentDTO>> listAppointments() throws ResourceNotFoundException {
        return ResponseEntity.ok(appointmentService.appointmentsDTOList());
    }

}
