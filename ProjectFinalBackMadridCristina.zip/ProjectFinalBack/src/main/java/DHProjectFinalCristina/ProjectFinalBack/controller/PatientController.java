package DHProjectFinalCristina.ProjectFinalBack.controller;
import DHProjectFinalCristina.ProjectFinalBack.entity.Patient;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/patients")
public class PatientController {

    private PatientService patientService;

    @Autowired
    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }
    @PostMapping
    public ResponseEntity<Patient> registerPatient(@RequestBody Patient patient){
        return ResponseEntity.ok(patientService.savePatient(patient));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Patient> patientSearch(@PathVariable Long id) throws ResourceNotFoundException {
        return ResponseEntity.ok(patientService.searchPatient(id).get());
    }
    @GetMapping("/search/{email}")
    public ResponseEntity<Patient> searchPatientByEmail(@PathVariable String email) throws ResourceNotFoundException {
        return ResponseEntity.ok(patientService.searchPatientByEmail(email).get());
    }

    @PutMapping
    public ResponseEntity<String> patientUpdate(@RequestBody Patient patient) throws ResourceNotFoundException{
        patientService.updatePatient(patient);
        return ResponseEntity.ok("The patient with id: " + patient.getId() +", was updated");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> patientDelete(@PathVariable Long id) throws ResourceNotFoundException {
        patientService.deletePatient(id);
        return ResponseEntity.ok("Removed patient with id: " + id);
    }

    @GetMapping
    public ResponseEntity<List<Patient>> patientsList() throws ResourceNotFoundException {
        return ResponseEntity.ok( patientService.listPatients());
    }

}
