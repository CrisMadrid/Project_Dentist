package DHProjectFinalCristina.ProjectFinalBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFinalBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectFinalBackApplication.class, args);
	}

}
