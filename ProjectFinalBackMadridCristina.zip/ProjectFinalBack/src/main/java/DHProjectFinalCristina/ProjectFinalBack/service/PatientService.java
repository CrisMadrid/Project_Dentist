package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.entity.Patient;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.repository.PatientRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {
    private static final Logger LOGGER = Logger.getLogger(Patient.class);

    private PatientRepository patientRepository;

    @Autowired
    public PatientService(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    public Patient savePatient (Patient patient){
        LOGGER.info("Starting the saving process of the patient with name: " + patient.getName());
        return patientRepository.save(patient);
    }

    public Optional<Patient> searchPatient (Long id) throws ResourceNotFoundException {
        Optional<Patient> patientToSearch = patientRepository.findById(id);
        if(patientToSearch.isPresent()){
            LOGGER.info("Starting patient search process with id: " + id);
            return patientToSearch;
        }else {
            throw new ResourceNotFoundException("The patient with id " + id + ", cannot be found, because it does not exist in our records.");
        }
    }
    public Optional <Patient> searchPatientByEmail(String email) throws ResourceNotFoundException {
        LOGGER.info("Se realizó la búsqueda del paciente con correo: " + email);
        Optional<Patient> searchToPatientByEmail = patientRepository.findByEmail(email);
        if(searchToPatientByEmail.isPresent()){
            return searchToPatientByEmail;
        }else {
            throw new ResourceNotFoundException("Cannot find patient with email: " + email + ", because it does not exist");
        }
    }

    public void updatePatient(Patient patient) throws ResourceNotFoundException{
        Optional<Patient> patientToUpdate = patientRepository.findById(patient.getId());
        if(patientToUpdate.isPresent()) {
            LOGGER.warn("Starting patient update process with id: " + patient.getId());
            patientRepository.save(patient);
        }else {
            throw new ResourceNotFoundException("Cannot update patient with id: " + patient.getId() + ", because it does not exist in our records.");
        }
    }

    public void deletePatient(Long id) throws ResourceNotFoundException {
        Optional<Patient> patientToDelete = patientRepository.findById(id);
        if(patientToDelete.isPresent()){
            patientRepository.deleteById(id);
            LOGGER.warn("The patient with id: " + id + ", has been removed");
        }else{
            throw new ResourceNotFoundException("Cannot delete patient with id: " + id + ", because it does not exist in our records.");
        }
    }

    public List<Patient> listPatients() throws ResourceNotFoundException {
        LOGGER.info("The search was carried out for all patients");
        List<Patient> dentistList = patientRepository.findAll();
        if(dentistList.size()>0){
            return dentistList;
        }else {
            throw new ResourceNotFoundException("No patients can be found because there are no records");
        }
    }

}
