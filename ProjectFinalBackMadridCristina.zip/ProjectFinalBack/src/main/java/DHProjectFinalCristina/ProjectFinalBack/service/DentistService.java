package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.entity.Dentist;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.repository.DentistRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DentistService {
    private static final Logger LOGGER = Logger.getLogger(DentistService.class);

    private DentistRepository dentistRepository;

    @Autowired
    public DentistService(DentistRepository dentistRepository) {
        this.dentistRepository = dentistRepository;
    }
    public Dentist saveDentist(Dentist dentist){
        LOGGER.info("Starting the saving process of the dentist with name: " + dentist.getName());
        return dentistRepository.save(dentist);
    }

    public Optional<Dentist> searchDentist(Long id) throws ResourceNotFoundException{
        Optional<Dentist> dentistToSearch = dentistRepository.findById(id);
        if(dentistToSearch.isPresent()){
            LOGGER.info("Starting dentist search process with id: " + id);
            return dentistToSearch;
        }else {
            throw new ResourceNotFoundException("The dentist with id " + id + ", cannot be found, because it does not exist in our records");
        }
    }

    public void updateDentist(Dentist dentist) throws ResourceNotFoundException{
        Optional<Dentist> dentistToUpdate = dentistRepository.findById(dentist.getId());
        if(dentistToUpdate.isPresent()) {
            LOGGER.warn("Starting dentist update process with id: " + dentist.getId());
            dentistRepository.save(dentist);
        }else {
            throw new ResourceNotFoundException("Cannot update dentist with id: " + dentist.getId() + ", because it does not exist in the records");
        }
    }

    public void deleteDentist(Long id) throws ResourceNotFoundException {
        Optional<Dentist> dentistToDelete = dentistRepository.findById(id);
        if(dentistToDelete.isPresent()){
            dentistRepository.deleteById(id);
            LOGGER.warn("The dentist with id: " + id + ", has been removed");
        }else{
            throw new ResourceNotFoundException("Cannot delete dentist with id: " + id + ", because it does not exist in the records");
        }
    }

    public List<Dentist> listdentists() throws ResourceNotFoundException {
        LOGGER.info("The search was carried out for all dentists");
        List<Dentist> dentistList = dentistRepository.findAll();
        if(dentistList.size()>0){
            return dentistList;
        }else {
            throw new ResourceNotFoundException("No dentist can be found because there are no records");
        }
    }

}
