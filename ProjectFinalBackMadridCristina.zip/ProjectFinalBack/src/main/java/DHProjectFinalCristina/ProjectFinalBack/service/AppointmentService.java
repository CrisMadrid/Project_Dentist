package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.dto.AppointmentDTO;
import DHProjectFinalCristina.ProjectFinalBack.entity.Appointment;
import DHProjectFinalCristina.ProjectFinalBack.entity.Dentist;
import DHProjectFinalCristina.ProjectFinalBack.entity.Patient;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.BadRequestException;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import DHProjectFinalCristina.ProjectFinalBack.repository.AppointmentRepository;
import DHProjectFinalCristina.ProjectFinalBack.repository.DentistRepository;
import DHProjectFinalCristina.ProjectFinalBack.repository.PatientRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {
    private static final Logger LOGGER = Logger.getLogger(Appointment.class);

    private AppointmentRepository appointmentRepository;
    private DentistRepository dentistRepository;
    private PatientRepository patientRepository;

    @Autowired
    public AppointmentService(AppointmentRepository appointmentRepository, DentistRepository dentistRepository, PatientRepository patientRepository) {
        this.appointmentRepository = appointmentRepository;
        this.dentistRepository = dentistRepository;
        this.patientRepository = patientRepository;
    }


    private AppointmentDTO appointmentToAppointmentDTO(Appointment appointment){
        AppointmentDTO answer = new AppointmentDTO();
        answer.setId(appointment.getId());
        answer.setDentist_id(appointment.getDentist().getId());
        answer.setPatient_id(appointment.getPatient().getId());
        answer.setDate(appointment.getDate());
        return answer;
    }

    private Appointment appointmentDTOToAppointment(AppointmentDTO appointmentDTO){
        Appointment answer = new Appointment();
        Dentist dentist = new Dentist();
        Patient patient = new Patient();
        dentist.setId(appointmentDTO.getDentist_id());
        patient.setId(appointmentDTO.getPatient_id());
        answer.setDentist(dentist);
        answer.setPatient(patient);
        answer.setDate(appointmentDTO.getDate());
        answer.setId(appointmentDTO.getId());
        return answer;
    }

    public AppointmentDTO saveAppointment(AppointmentDTO appointmentDTO) throws BadRequestException {
        if(dentistRepository.findById(appointmentDTO.getDentist_id()).isPresent() && patientRepository.findById(appointmentDTO.getPatient_id()).isPresent()){
            LOGGER.info("The process to register the patient's appointment with id: " + appointmentDTO.getPatient_id() + ", was started:");
            Appointment appointmentSave = appointmentRepository.save(appointmentDTOToAppointment(appointmentDTO));
            return appointmentToAppointmentDTO(appointmentSave);
        }else{
            throw new BadRequestException("Cannot register shift because the patient or dentist does not exist");
        }

    }

    public Optional<AppointmentDTO> searchAppointment(Long id) throws BadRequestException {
        Optional<Appointment> appointmentSearched = appointmentRepository.findById(id);
        if(appointmentSearched.isPresent()){
            return Optional.of(appointmentToAppointmentDTO(appointmentSearched.get()));
        }else {
            throw new BadRequestException("The appointment with id " + id + ", cannot be found, " +
                    "because it does not exist in our records.");
        }
    }
    public void updateAppointment(AppointmentDTO appointmentDTO) throws ResourceNotFoundException {
        Optional<Appointment> appointmentToUpdate = appointmentRepository.findById(appointmentDTO.getId());
        if(appointmentToUpdate.isPresent()) {
            LOGGER.warn("Starting appointment update process with id: " + appointmentDTO.getId());
            appointmentRepository.save(appointmentDTOToAppointment(appointmentDTO));
        }else {
            throw new ResourceNotFoundException("Cannot update appointment with id: " + appointmentDTO.getId() + ", because it does not exist in the records");
        }
    }

    public void deleteAppointment(Long id) throws ResourceNotFoundException {
        Optional<Appointment> appointmentToDelete = appointmentRepository.findById(id);
        if(appointmentToDelete.isPresent()){
            appointmentRepository.deleteById(id);
            LOGGER.warn("The appointment with id: " + id + ", has been removed");
        }else{
            throw new ResourceNotFoundException("Cannot delete appointment with id: " + id + ", because it does not exist in our records.");
        }
    }

    public List<AppointmentDTO> appointmentsDTOList() throws ResourceNotFoundException {
        LOGGER.info("The search was carried out for all appointments");
        List<Appointment> appointmentsList = appointmentRepository.findAll();
        List<AppointmentDTO> appointmentDTOS = new ArrayList<>();
        for (Appointment appointment: appointmentsList){
            appointmentDTOS.add(appointmentToAppointmentDTO(appointment));
        }
        if(appointmentsList.size()>0){
            return appointmentDTOS;
        }else {
            throw new ResourceNotFoundException("No appointments can be found because there are no records");
        }
    }

}
