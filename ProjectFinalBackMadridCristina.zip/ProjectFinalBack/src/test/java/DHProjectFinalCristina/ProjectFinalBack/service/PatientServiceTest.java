package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.entity.Address;
import DHProjectFinalCristina.ProjectFinalBack.entity.Patient;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
class PatientServiceTest {
    @Autowired
    private PatientService patientService;

    @Test
    @Order(1)
    public void savePatientTest(){
        Patient patientToSave = new Patient ("Jorge","Navarro", "1234", LocalDate.of(2022,12,25),
                "jorgenavarro@gmail.com",new Address("Calle A",333,"Medellin", "Antioquia"));
        Patient patientSave = patientService.savePatient(patientToSave);
        assertEquals(1L,patientToSave.getId());
    }

    @Test
    @Order(2)
    public void searchPatientByIdTest() throws ResourceNotFoundException {
        Long idToSearch = 1L;
        Optional<Patient> patientSearched = patientService.searchPatient(idToSearch);
        assertNotNull(patientSearched.get());
    }

    @Test
    @Order(3)
    public void searchPatientsTest() throws ResourceNotFoundException {
        List<Patient> patientList = patientService.listPatients();
        assertEquals(1,patientList.size());
    }

    @Test
    @Order(4)
    public void updatePatientTest() throws ResourceNotFoundException {
        Patient patientToUpdate = new Patient(1L,"Luis","Navarro", "1234", LocalDate.of(2022,12,25),
                "jorgenavarro@gmail.com",new Address(1L,"Calle A",333,"Medellin", "Antioquia"));
        patientService.updatePatient(patientToUpdate);
        Optional<Patient> patientUpdate = patientService.searchPatient(1L);
        assertEquals("Luis",patientUpdate.get().getName());
    }

    @Test
    @Order(5)
    public void deletePatientTest() throws ResourceNotFoundException {
        Long idToDelete = 1L;
        patientService.deletePatient(idToDelete);
        assertThrows(ResourceNotFoundException.class,()->patientService.searchPatient(idToDelete));
    }
}