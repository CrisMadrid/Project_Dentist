package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.entity.Dentist;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
class DentistServiceTest {

    @Autowired
    DentistService dentistService;

    @Test
    @Order(1)
    public void saveDentistTest(){
        Dentist dentistToSave = new Dentist("1234","Leydy","Tangarife");
        Dentist dentistSaved = dentistService.saveDentist(dentistToSave);
        assertEquals(1L,dentistSaved.getId());
    }

    @Test
    @Order(2)
    public void searchDentistByIdTest() throws ResourceNotFoundException {
        Long idToSearch = 1L;
        Optional<Dentist> dentistSearched = dentistService.searchDentist(idToSearch);
        assertNotNull(dentistSearched);
    }

    @Test
    @Order(3)
    public void searchDentistsTest() throws ResourceNotFoundException {
        List<Dentist> dentistList = dentistService.listdentists();
        assertEquals(1,dentistList.size());
    }

    @Test
    @Order(4)
    public void updateDentistTest() throws ResourceNotFoundException {
        Dentist dentistToUpdate = new Dentist(1L,"333CB","Leydy","Tangarife");
        dentistService.updateDentist(dentistToUpdate);
        Optional<Dentist> dentistUpdated = dentistService.searchDentist(1L);
        assertEquals("333CB",dentistUpdated.get().getRegistrationNum());
    }

    @Test
    @Order(5)
    public void deleteDentistTest() throws ResourceNotFoundException {
        Long idToDelete = 1L;
        dentistService.deleteDentist(idToDelete);
        assertThrows(ResourceNotFoundException.class,()->dentistService.searchDentist(idToDelete));
    }

}