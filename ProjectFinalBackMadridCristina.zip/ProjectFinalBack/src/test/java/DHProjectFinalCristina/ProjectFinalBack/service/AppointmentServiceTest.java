package DHProjectFinalCristina.ProjectFinalBack.service;

import DHProjectFinalCristina.ProjectFinalBack.dto.AppointmentDTO;
import DHProjectFinalCristina.ProjectFinalBack.entity.Address;
import DHProjectFinalCristina.ProjectFinalBack.entity.Dentist;
import DHProjectFinalCristina.ProjectFinalBack.entity.Patient;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.BadRequestException;
import DHProjectFinalCristina.ProjectFinalBack.exceptions.ResourceNotFoundException;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest
class AppointmentServiceTest {

    @Autowired
    private DentistService dentistService;
    @Autowired
    private PatientService patientService;
    @Autowired
    private AppointmentService appointmentService;

    @Test
    @Order(1)
    public void saveAppointmentTest() throws BadRequestException {
        Dentist dentistToSave = new Dentist("123CB","Leydy","Tangarife");
        Dentist addDentist = dentistService.saveDentist(dentistToSave);
        Patient patientToSave = new Patient("Isabelle","Bhome","555", LocalDate.of(2022,12,25),"isbo@gmail.com",
                new Address("35B",45,"Medellin","Antioquia"));
        Patient addPatient = patientService.savePatient(patientToSave);
        AppointmentDTO appointmentDTO = new AppointmentDTO();
        appointmentDTO.setDate(LocalDate.of(2023,02,23));
        appointmentDTO.setDentist_id(addDentist.getId());
        appointmentDTO.setPatient_id(addPatient.getId());
        AppointmentDTO answer = appointmentService.saveAppointment(appointmentDTO);
        assertEquals(1L,answer.getId());
    }

    @Test
    @Order(2)
    public void searchAppointmentByIdTest() throws  BadRequestException {
        Long idToSearch = 1L;
        Optional<AppointmentDTO> appointmentSearched = appointmentService.searchAppointment(idToSearch);
        assertNotNull(appointmentSearched.get());
    }
    @Test
    @Order(3)
    public void searchAppointmentsTest() throws ResourceNotFoundException {
        List<AppointmentDTO> appointmentDTOS = appointmentService.appointmentsDTOList();
        assertEquals(1,appointmentDTOS.size());
    }

    @Test
    @Order(4)
    public void updateAppointmentTest() throws ResourceNotFoundException, BadRequestException {
        Long idToSearch = 1L;
        Optional<Dentist> dentistSearched = dentistService.searchDentist(idToSearch);
        Optional<Patient> patientSearched = patientService.searchPatient(idToSearch);
        AppointmentDTO appointmentDTO = new AppointmentDTO();
        appointmentDTO.setId(idToSearch);
        appointmentDTO.setDate(LocalDate.of(2022,12,20));
        appointmentDTO.setDentist_id(dentistSearched.get().getId());
        appointmentDTO.setPatient_id(patientSearched.get().getId());
        appointmentService.updateAppointment(appointmentDTO);
        Optional<AppointmentDTO> appointmentDTOUpdated = appointmentService.searchAppointment(1L);
        assertEquals(LocalDate.of(2022,12,20), appointmentDTOUpdated.get().getDate());
    }
    @Test
    @Order(5)
    public void deleteAppointmentTest() throws ResourceNotFoundException {
        Long idToDelete = 1L;
        appointmentService.deleteAppointment(idToDelete);
        assertThrows(BadRequestException.class,()->appointmentService.searchAppointment(idToDelete));

    }

}